import spacy
import string

# ✅ Load NLP model
nlp = spacy.load("en_core_web_sm")

# ✅ Function to clean text
def preprocess_text(text):
    return text.translate(str.maketrans("", "", string.punctuation))

# ✅ AI-powered Text-to-ISL conversion
def convert_to_isl(text):
    text = preprocess_text(text)
    doc = nlp(text)
    
    subject, verb, obj, other_words = [], [], [], []
    greetings = {"hello", "hi", "hey"}
    detected_greeting = None

    for token in doc:
        lemma = token.lemma_

        if lemma in greetings and not detected_greeting:
            detected_greeting = lemma  # Identify greetings
        elif token.pos_ in ["AUX", "DET", "ADP"]:
            continue  # Skip unnecessary words
        elif token.dep_ in ["nsubj", "nsubjpass"]:
            subject.append(lemma)  # Identify subject
        elif token.dep_ in ["dobj", "pobj"]:
            obj.append(lemma)  # Identify object
        elif token.pos_ == "VERB":
            verb.append(lemma)  # Identify verb
        else:
            other_words.append(lemma)  # Other words

    isl_sentence = [detected_greeting] if detected_greeting else []
    isl_sentence += subject + obj + verb + other_words
    return " ".join(isl_sentence)
