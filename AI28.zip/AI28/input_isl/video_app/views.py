import os
from django.conf import settings
from django.shortcuts import render
from django.http import JsonResponse
from django.core.files.storage import default_storage
from .utils.video_to_text import video_to_text
from .utils.audio_to_text import audio_to_text
from .utils.text_to_isl import convert_to_isl
from .utils.isl_video_matcher import find_best_match
from video_app.apps import isl_trie

MEDIA_DIR = os.path.join(settings.BASE_DIR, 'media')

def index(request):
    return render(request, 'converter.html')

def process_media(request):
    isl_video_paths = []
    extracted_text = ""
    uploaded_video_path = None

    if request.method == 'POST':
        if request.FILES.get('video'):
            file = request.FILES['video']
            uploaded_video_path = default_storage.save(f'media/{file.name}', file)
            extracted_text = video_to_text(uploaded_video_path)

        elif request.FILES.get('audio'):
            file = request.FILES['audio']
            file_path = default_storage.save(f'media/{file.name}', file)
            extracted_text = audio_to_text(file_path)

        elif request.POST.get('text'):
            extracted_text = request.POST.get('text')

        else:
            return JsonResponse({'error': 'No valid media uploaded'}, status=400)

        #  Convert extracted text to ISL format using AI NLP
        isl_text = convert_to_isl(extracted_text)
        words = isl_text.split()

        #  Find the best ISL video for each word
        for word in words:
            video_file_path = os.path.join(MEDIA_DIR, f"{word}.mp4")
            if os.path.exists(video_file_path):
                isl_video_paths.append(f"/media/{word}.mp4")  #  Correct path
            else:
                best_match = isl_trie.search(word) or find_best_match(word)  # AI-based search
                if best_match:
                    isl_video_paths.append(f"/media/{best_match}.mp4")

        return render(request, 'converter.html', {
            'transcribed_text': extracted_text,
            'isl_text': isl_text,
            'video_paths': isl_video_paths,
            'uploaded_video': f"/{uploaded_video_path}" if uploaded_video_path else None
        })

    return render(request, 'converter.html')
