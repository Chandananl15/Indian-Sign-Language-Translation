from django.urls import path
from django.contrib.auth import views as auth_views
from video_app.views import index, process_media

urlpatterns = [
    path('', index, name='home'),
    path('process-media/', process_media, name='process_media'),
]
